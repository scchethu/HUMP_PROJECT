<!DOCTYPE html>
<html>
<head>
	<title>Municipality Monitor</title>
</head>
<link rel="stylesheet" type="text/css" href="w3.css">
<body style="background-image: url(bg.png);background-size: cover;">
<div class="w3-card-4 w3-margin w3-padding-large w3-center w3-teal w3-xlarge ">
	Municipality Monitor
</div>
<div class="w3-container" >
<!--div class="w3-right">
	<a href="">Login</a>
	<a href="">Register</a>
</div-->
	<div class="w3-row" style="margin-left: 18%;margin-top: 20%;">

		<div class="w3-half">
			<a href="monitor.html" class="w3-btn w3-green w3-hover-red w3-half w3-padding-large">Bin Monitor</a>
		</div>
		<div class="w3-half">
			<a href="track.html" class="w3-btn w3-green w3-hover-red w3-half w3-padding-large">Track Bin</a>
		</div>
	</div>
	</div>
	
</body>
</html>