<?php

echo file_get_contents("loc.txt");


?>