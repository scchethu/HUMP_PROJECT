package hump.sdmit.humpdetect;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

public class Splashscreen extends AppCompatActivity {

    private static final String TAG = "fire";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);
        // Get token
        // [START retrieve_current_token]
//        FirebaseInstanceId.getInstance().getInstanceId()
//                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
//                        if (!task.isSuccessful()) {
//                            Log.w(TAG, "getInstanceId failed", task.getException());
//                            return;
//                        }
//
//                        // Get new Instance ID token
//                        String token = task.getResult().getToken();
//
//                        // Log and toast
//                        String msg = "Success";
//                        Log.d(TAG, msg);
//                        Toast.makeText(Splashscreen.this, msg, Toast.LENGTH_SHORT).show();
//                    }
//                });
//        // [END retrieve_current_token]
//
//       // Toast.makeText(this, FirebaseInstanceId.getInstance().getToken(), Toast.LENGTH_SHORT).show();
//        // [END retrieve_current_token]
//
//        Log.d(TAG, "Subscribing to weather topic");
//        // [START subscribe_topics]
//        FirebaseMessaging.getInstance().subscribeToTopic("weather")
//                .addOnCompleteListener(new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//                        String msg = "succes";
//                        if (!task.isSuccessful()) {
//                            msg = "faidled";
//                        }
//                        Log.d(TAG, msg);
//                        Toast.makeText(Splashscreen.this, msg, Toast.LENGTH_SHORT).show();
//                    }
//                });
        // [END subscribe_topics]





        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               startActivity(new Intent(Splashscreen.this, MainActivity.class));
            }
        }, 2000);
    }
}

